import React, { useState } from 'react';
import {
  Worksheet,
  Part1Question,
  Part2Question,
  Part3Question,
  Part4Question,
  CognitiveLevel,
} from '../types/worksheet';
import { MathRenderer } from './MathRenderer';
import { MathSymbolPicker } from './MathSymbolPicker';
import {
  Plus,
  Trash2,
  Save,
  CheckCircle,
  HelpCircle,
  BookOpen,
} from 'lucide-react';

interface WorksheetEditorProps {
  worksheet: Worksheet;
  onSave: (updated: Worksheet) => void;
  onCancel: () => void;
}

export const WorksheetEditor: React.FC<WorksheetEditorProps> = ({
  worksheet,
  onSave,
  onCancel,
}) => {
  const [data, setData] = useState<Worksheet>(JSON.parse(JSON.stringify(worksheet)));
  const [activeTab, setActiveTab] = useState<'info' | 'part1' | 'part2' | 'part3' | 'part4'>('part1');
  const [focusedInputInfo, setFocusedInputInfo] = useState<{
    target: string;
    index?: number;
    subKey?: string;
  } | null>(null);

  // Math symbol insertion handler
  const handleInsertSymbol = (snippet: string) => {
    if (!focusedInputInfo) return;

    const { target, index, subKey } = focusedInputInfo;

    setData((prev) => {
      const copy = { ...prev };
      if (target === 'p1_content' && typeof index === 'number') {
        copy.part1[index].content = (copy.part1[index].content || '') + snippet;
      } else if (target === 'p1_option' && typeof index === 'number' && subKey) {
        copy.part1[index].options[subKey as 'A' | 'B' | 'C' | 'D'] =
          (copy.part1[index].options[subKey as 'A' | 'B' | 'C' | 'D'] || '') + snippet;
      } else if (target === 'p2_content' && typeof index === 'number') {
        copy.part2[index].content = (copy.part2[index].content || '') + snippet;
      } else if (target === 'p2_stmt' && typeof index === 'number' && subKey) {
        const stmtIdx = copy.part2[index].statements.findIndex((s) => s.id === subKey);
        if (stmtIdx !== -1) {
          copy.part2[index].statements[stmtIdx].content =
            (copy.part2[index].statements[stmtIdx].content || '') + snippet;
        }
      } else if (target === 'p3_content' && typeof index === 'number') {
        copy.part3[index].content = (copy.part3[index].content || '') + snippet;
      } else if (target === 'p4_content' && typeof index === 'number') {
        copy.part4[index].content = (copy.part4[index].content || '') + snippet;
      } else if (target === 'p4_solution' && typeof index === 'number') {
        copy.part4[index].solution = (copy.part4[index].solution || '') + snippet;
      }
      return copy;
    });
  };

  // Add new question to Part 1
  const handleAddPart1 = () => {
    const newQ: Part1Question = {
      id: `p1_q_${Date.now()}`,
      code: `Câu ${data.part1.length + 1}`,
      content: 'Nội dung câu hỏi mới... Cho $x = ...$',
      level: 'nhan_biet',
      options: {
        A: 'Phương án A',
        B: 'Phương án B',
        C: 'Phương án C',
        D: 'Phương án D',
      },
      correctAnswer: 'A',
      points: 0.25,
      explanation: 'Hướng dẫn giải chi tiết cho câu hỏi.',
    };
    setData((prev) => ({ ...prev, part1: [...prev.part1, newQ] }));
  };

  // Add new question to Part 2
  const handleAddPart2 = () => {
    const newQ: Part2Question = {
      id: `p2_q_${Date.now()}`,
      code: `Câu ${data.part2.length + 1}`,
      content: 'Cho hàm số / hình học / biểu thức... Xét tính Đúng/Sai của các mệnh đề sau:',
      level: 'thong_hieu',
      points: 1.0,
      explanation: 'Lời giải tổng quan cho bài toán.',
      statements: [
        { id: 'a', content: 'Khẳng định a là...', isCorrect: true, explanation: '' },
        { id: 'b', content: 'Khẳng định b là...', isCorrect: false, explanation: '' },
        { id: 'c', content: 'Khẳng định c là...', isCorrect: true, explanation: '' },
        { id: 'd', content: 'Khẳng định d là...', isCorrect: false, explanation: '' },
      ],
    };
    setData((prev) => ({ ...prev, part2: [...prev.part2, newQ] }));
  };

  // Add new question to Part 3
  const handleAddPart3 = () => {
    const newQ: Part3Question = {
      id: `p3_q_${Date.now()}`,
      code: `Câu ${data.part3.length + 1}`,
      content: 'Tính giá trị của... (Học sinh điền kết quả ngắn)',
      level: 'van_dung',
      correctAnswer: '10',
      acceptableAnswers: ['10'],
      points: 0.5,
      explanation: 'Lời giải chi tiết.',
    };
    setData((prev) => ({ ...prev, part3: [...prev.part3, newQ] }));
  };

  // Add new question to Part 4
  const handleAddPart4 = () => {
    const newQ: Part4Question = {
      id: `p4_q_${Date.now()}`,
      code: `Bài ${data.part4.length + 1}`,
      content: 'Bài toán tự luận: 1) Rút gọn... 2) Tìm x...',
      level: 'van_dung',
      points: 2.0,
      rubric: [
        { stepDescription: 'Ý 1: Giải đúng bước đầu', points: 1.0 },
        { stepDescription: 'Ý 2: Kết luận chính xác', points: 1.0 },
      ],
      solution: 'Lời giải mẫu chi tiết từng bước...',
    };
    setData((prev) => ({ ...prev, part4: [...prev.part4, newQ] }));
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-20">
      {/* Editor Top Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <span>✏️ Biên Soạn Phiếu Bài Tập</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
              Chuẩn CV 7991
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Chỉnh sửa thông tin, ma trận câu hỏi và công thức toán học với KaTeX
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
          >
            Hủy bỏ
          </button>
          <button
            type="button"
            onClick={() => onSave(data)}
            className="flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md shadow-indigo-200 transition"
          >
            <Save className="w-4 h-4" />
            <span>Lưu thay đổi</span>
          </button>
        </div>
      </div>

      {/* Floating Math Symbol Picker */}
      <div className="bg-white rounded-2xl border border-slate-200 p-3 shadow-xs">
        <MathSymbolPicker onInsert={handleInsertSymbol} />
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('info')}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
            activeTab === 'info'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100'
          }`}
        >
          Thông tin chung
        </button>
        <button
          onClick={() => setActiveTab('part1')}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
            activeTab === 'part1'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100'
          }`}
        >
          Phần I: Nhiều lựa chọn ({data.part1.length})
        </button>
        <button
          onClick={() => setActiveTab('part2')}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
            activeTab === 'part2'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100'
          }`}
        >
          Phần II: Đúng / Sai ({data.part2.length})
        </button>
        <button
          onClick={() => setActiveTab('part3')}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
            activeTab === 'part3'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100'
          }`}
        >
          Phần III: Trả lời ngắn ({data.part3.length})
        </button>
        <button
          onClick={() => setActiveTab('part4')}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
            activeTab === 'part4'
              ? 'bg-rose-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100'
          }`}
        >
          Phần IV: Tự luận ({data.part4.length})
        </button>
      </div>

      {/* TAB: THÔNG TIN CHUNG */}
      {activeTab === 'info' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-base font-bold text-slate-900 mb-2">Thông tin phiếu bài tập / đề thi</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Tiêu đề phiếu:</label>
              <input
                type="text"
                value={data.metadata.title}
                onChange={(e) =>
                  setData((prev) => ({
                    ...prev,
                    metadata: { ...prev.metadata, title: e.target.value },
                  }))
                }
                className="w-full p-2.5 border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Chủ đề / Bài học:</label>
              <input
                type="text"
                value={data.metadata.topic}
                onChange={(e) =>
                  setData((prev) => ({
                    ...prev,
                    metadata: { ...prev.metadata, topic: e.target.value },
                  }))
                }
                className="w-full p-2.5 border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Tên trường / Đơn vị:</label>
              <input
                type="text"
                value={data.metadata.schoolName}
                onChange={(e) =>
                  setData((prev) => ({
                    ...prev,
                    metadata: { ...prev.metadata, schoolName: e.target.value },
                  }))
                }
                className="w-full p-2.5 border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Năm học:</label>
              <input
                type="text"
                value={data.metadata.academicYear}
                onChange={(e) =>
                  setData((prev) => ({
                    ...prev,
                    metadata: { ...prev.metadata, academicYear: e.target.value },
                  }))
                }
                className="w-full p-2.5 border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Thời gian làm bài (phút):</label>
              <input
                type="number"
                value={data.metadata.durationMinutes}
                onChange={(e) =>
                  setData((prev) => ({
                    ...prev,
                    metadata: { ...prev.metadata, durationMinutes: Number(e.target.value) },
                  }))
                }
                className="w-full p-2.5 border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Tác giả / Giáo viên biên soạn:</label>
              <input
                type="text"
                value={data.metadata.author}
                onChange={(e) =>
                  setData((prev) => ({
                    ...prev,
                    metadata: { ...prev.metadata, author: e.target.value },
                  }))
                }
                className="w-full p-2.5 border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>
          </div>
        </div>
      )}

      {/* TAB: PHẦN I (Nhiều lựa chọn) */}
      {activeTab === 'part1' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">
              Phần I: Câu hỏi trắc nghiệm nhiều phương án lựa chọn (A, B, C, D)
            </h3>
            <button
              type="button"
              onClick={handleAddPart1}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-xl text-xs font-bold transition"
            >
              <Plus className="w-4 h-4" />
              <span>Thêm câu hỏi</span>
            </button>
          </div>

          <div className="space-y-6">
            {data.part1.map((q, idx) => (
              <div key={q.id} className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-xs">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={q.code}
                      onChange={(e) => {
                        const copy = [...data.part1];
                        copy[idx].code = e.target.value;
                        setData({ ...data, part1: copy });
                      }}
                      className="w-20 px-2 py-1 font-bold text-xs border border-slate-300 rounded"
                    />
                    <select
                      value={q.level}
                      onChange={(e) => {
                        const copy = [...data.part1];
                        copy[idx].level = e.target.value as CognitiveLevel;
                        setData({ ...data, part1: copy });
                      }}
                      className="text-xs border border-slate-300 rounded px-2 py-1"
                    >
                      <option value="nhan_biet">Nhận biết</option>
                      <option value="thong_hieu">Thông hiểu</option>
                      <option value="van_dung">Vận dụng</option>
                      <option value="van_dung_cao">Vận dụng cao</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 font-bold">Điểm:</span>
                    <input
                      type="number"
                      step="0.05"
                      value={q.points}
                      onChange={(e) => {
                        const copy = [...data.part1];
                        copy[idx].points = Number(e.target.value);
                        setData({ ...data, part1: copy });
                      }}
                      className="w-16 px-2 py-1 text-xs border border-slate-300 rounded font-bold"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const copy = data.part1.filter((_, i) => i !== idx);
                        setData({ ...data, part1: copy });
                      }}
                      className="text-rose-500 hover:text-rose-700 p-1"
                      title="Xóa câu này"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Content input */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Nội dung câu hỏi:</label>
                  <textarea
                    rows={2}
                    value={q.content}
                    onFocus={() => setFocusedInputInfo({ target: 'p1_content', index: idx })}
                    onChange={(e) => {
                      const copy = [...data.part1];
                      copy[idx].content = e.target.value;
                      setData({ ...data, part1: copy });
                    }}
                    className="w-full p-2.5 border border-slate-300 rounded-lg text-sm font-sans text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  />
                  <div className="mt-1 p-2 bg-slate-50 rounded border border-slate-200 text-xs">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                      Xem trước công thức:
                    </span>
                    <MathRenderer content={q.content} />
                  </div>
                </div>

                {/* 4 Options */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {(['A', 'B', 'C', 'D'] as const).map((opt) => (
                    <div key={opt} className="space-y-1">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold text-slate-700">Phương án {opt}:</label>
                        <label className="flex items-center gap-1 text-xs text-slate-600 cursor-pointer">
                          <input
                            type="radio"
                            name={`correct_p1_${idx}`}
                            checked={q.correctAnswer === opt}
                            onChange={() => {
                              const copy = [...data.part1];
                              copy[idx].correctAnswer = opt;
                              setData({ ...data, part1: copy });
                            }}
                          />
                          <span className={q.correctAnswer === opt ? 'font-bold text-emerald-600' : ''}>
                            Đúng
                          </span>
                        </label>
                      </div>
                      <input
                        type="text"
                        value={q.options[opt]}
                        onFocus={() =>
                          setFocusedInputInfo({ target: 'p1_option', index: idx, subKey: opt })
                        }
                        onChange={(e) => {
                          const copy = [...data.part1];
                          copy[idx].options[opt] = e.target.value;
                          setData({ ...data, part1: copy });
                        }}
                        className="w-full p-2 border border-slate-300 rounded-lg text-sm text-slate-900"
                      />
                    </div>
                  ))}
                </div>

                {/* Explanation */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Hướng dẫn giải / Lời giải chi tiết:
                  </label>
                  <textarea
                    rows={2}
                    value={q.explanation}
                    onChange={(e) => {
                      const copy = [...data.part1];
                      copy[idx].explanation = e.target.value;
                      setData({ ...data, part1: copy });
                    }}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs text-slate-900"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: PHẦN II (Đúng / Sai) */}
      {activeTab === 'part2' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">
              Phần II: Câu hỏi trắc nghiệm Đúng / Sai (Mỗi câu gồm 4 ý a, b, c, d)
            </h3>
            <button
              type="button"
              onClick={handleAddPart2}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-xl text-xs font-bold transition"
            >
              <Plus className="w-4 h-4" />
              <span>Thêm câu hỏi Đúng/Sai</span>
            </button>
          </div>

          <div className="space-y-6">
            {data.part2.map((q, idx) => (
              <div key={q.id} className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-xs">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={q.code}
                      onChange={(e) => {
                        const copy = [...data.part2];
                        copy[idx].code = e.target.value;
                        setData({ ...data, part2: copy });
                      }}
                      className="w-20 px-2 py-1 font-bold text-xs border border-slate-300 rounded"
                    />
                    <select
                      value={q.level}
                      onChange={(e) => {
                        const copy = [...data.part2];
                        copy[idx].level = e.target.value as CognitiveLevel;
                        setData({ ...data, part2: copy });
                      }}
                      className="text-xs border border-slate-300 rounded px-2 py-1"
                    >
                      <option value="nhan_biet">Nhận biết</option>
                      <option value="thong_hieu">Thông hiểu</option>
                      <option value="van_dung">Vận dụng</option>
                      <option value="van_dung_cao">Vận dụng cao</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 font-bold">Điểm:</span>
                    <input
                      type="number"
                      step="0.1"
                      value={q.points}
                      onChange={(e) => {
                        const copy = [...data.part2];
                        copy[idx].points = Number(e.target.value);
                        setData({ ...data, part2: copy });
                      }}
                      className="w-16 px-2 py-1 text-xs border border-slate-300 rounded font-bold"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const copy = data.part2.filter((_, i) => i !== idx);
                        setData({ ...data, part2: copy });
                      }}
                      className="text-rose-500 hover:text-rose-700 p-1"
                      title="Xóa câu này"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Question context */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Đề bài / Bối cảnh câu hỏi:
                  </label>
                  <textarea
                    rows={2}
                    value={q.content}
                    onFocus={() => setFocusedInputInfo({ target: 'p2_content', index: idx })}
                    onChange={(e) => {
                      const copy = [...data.part2];
                      copy[idx].content = e.target.value;
                      setData({ ...data, part2: copy });
                    }}
                    className="w-full p-2.5 border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                  <div className="mt-1 p-2 bg-slate-50 rounded border border-slate-200 text-xs">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                      Xem trước công thức:
                    </span>
                    <MathRenderer content={q.content} />
                  </div>
                </div>

                {/* 4 Statements */}
                <div className="space-y-3">
                  <label className="block text-xs font-bold text-slate-700">4 Ý mệnh đề (a, b, c, d):</label>
                  {q.statements.map((stmt, sIdx) => (
                    <div key={stmt.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-indigo-700 text-xs">Ý {stmt.id})</span>
                        <div className="flex items-center gap-3">
                          <label className="flex items-center gap-1 text-xs cursor-pointer">
                            <input
                              type="radio"
                              name={`p2_${idx}_stmt_${stmt.id}`}
                              checked={stmt.isCorrect === true}
                              onChange={() => {
                                const copy = [...data.part2];
                                copy[idx].statements[sIdx].isCorrect = true;
                                setData({ ...data, part2: copy });
                              }}
                            />
                            <span className={stmt.isCorrect ? 'font-bold text-emerald-600' : ''}>
                              Đúng
                            </span>
                          </label>
                          <label className="flex items-center gap-1 text-xs cursor-pointer">
                            <input
                              type="radio"
                              name={`p2_${idx}_stmt_${stmt.id}`}
                              checked={stmt.isCorrect === false}
                              onChange={() => {
                                const copy = [...data.part2];
                                copy[idx].statements[sIdx].isCorrect = false;
                                setData({ ...data, part2: copy });
                              }}
                            />
                            <span className={!stmt.isCorrect ? 'font-bold text-rose-600' : ''}>
                              Sai
                            </span>
                          </label>
                        </div>
                      </div>

                      <input
                        type="text"
                        value={stmt.content}
                        onFocus={() =>
                          setFocusedInputInfo({ target: 'p2_stmt', index: idx, subKey: stmt.id })
                        }
                        onChange={(e) => {
                          const copy = [...data.part2];
                          copy[idx].statements[sIdx].content = e.target.value;
                          setData({ ...data, part2: copy });
                        }}
                        placeholder="Nội dung mệnh đề..."
                        className="w-full p-2 bg-white border border-slate-300 rounded text-sm text-slate-900"
                      />
                    </div>
                  ))}
                </div>

                {/* Explanation */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Lời giải tổng quan:
                  </label>
                  <textarea
                    rows={2}
                    value={q.explanation}
                    onChange={(e) => {
                      const copy = [...data.part2];
                      copy[idx].explanation = e.target.value;
                      setData({ ...data, part2: copy });
                    }}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs text-slate-900"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: PHẦN III (Trả lời ngắn) */}
      {activeTab === 'part3' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">
              Phần III: Câu hỏi trắc nghiệm trả lời ngắn
            </h3>
            <button
              type="button"
              onClick={handleAddPart3}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-50 text-purple-700 hover:bg-purple-100 rounded-xl text-xs font-bold transition"
            >
              <Plus className="w-4 h-4" />
              <span>Thêm câu trả lời ngắn</span>
            </button>
          </div>

          <div className="space-y-6">
            {data.part3.map((q, idx) => (
              <div key={q.id} className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-xs">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={q.code}
                      onChange={(e) => {
                        const copy = [...data.part3];
                        copy[idx].code = e.target.value;
                        setData({ ...data, part3: copy });
                      }}
                      className="w-20 px-2 py-1 font-bold text-xs border border-slate-300 rounded"
                    />
                    <select
                      value={q.level}
                      onChange={(e) => {
                        const copy = [...data.part3];
                        copy[idx].level = e.target.value as CognitiveLevel;
                        setData({ ...data, part3: copy });
                      }}
                      className="text-xs border border-slate-300 rounded px-2 py-1"
                    >
                      <option value="nhan_biet">Nhận biết</option>
                      <option value="thong_hieu">Thông hiểu</option>
                      <option value="van_dung">Vận dụng</option>
                      <option value="van_dung_cao">Vận dụng cao</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 font-bold">Điểm:</span>
                    <input
                      type="number"
                      step="0.1"
                      value={q.points}
                      onChange={(e) => {
                        const copy = [...data.part3];
                        copy[idx].points = Number(e.target.value);
                        setData({ ...data, part3: copy });
                      }}
                      className="w-16 px-2 py-1 text-xs border border-slate-300 rounded font-bold"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const copy = data.part3.filter((_, i) => i !== idx);
                        setData({ ...data, part3: copy });
                      }}
                      className="text-rose-500 hover:text-rose-700 p-1"
                      title="Xóa câu này"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Nội dung câu hỏi:</label>
                  <textarea
                    rows={2}
                    value={q.content}
                    onFocus={() => setFocusedInputInfo({ target: 'p3_content', index: idx })}
                    onChange={(e) => {
                      const copy = [...data.part3];
                      copy[idx].content = e.target.value;
                      setData({ ...data, part3: copy });
                    }}
                    className="w-full p-2.5 border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  />
                  <div className="mt-1 p-2 bg-slate-50 rounded border border-slate-200 text-xs">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                      Xem trước công thức:
                    </span>
                    <MathRenderer content={q.content} />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Đáp số chuẩn:
                    </label>
                    <input
                      type="text"
                      value={q.correctAnswer}
                      onChange={(e) => {
                        const copy = [...data.part3];
                        copy[idx].correctAnswer = e.target.value;
                        setData({ ...data, part3: copy });
                      }}
                      className="w-full p-2 border border-slate-300 rounded-lg text-sm font-mono text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Đơn vị (nếu có):</label>
                    <input
                      type="text"
                      value={q.unit || ''}
                      placeholder="cm, cm², độ, m/s..."
                      onChange={(e) => {
                        const copy = [...data.part3];
                        copy[idx].unit = e.target.value;
                        setData({ ...data, part3: copy });
                      }}
                      className="w-full p-2 border border-slate-300 rounded-lg text-sm text-slate-900"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Hướng dẫn giải:
                  </label>
                  <textarea
                    rows={2}
                    value={q.explanation}
                    onChange={(e) => {
                      const copy = [...data.part3];
                      copy[idx].explanation = e.target.value;
                      setData({ ...data, part3: copy });
                    }}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs text-slate-900"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: PHẦN IV (Tự luận) */}
      {activeTab === 'part4' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">Phần IV: Bài tập tự luận</h3>
            <button
              type="button"
              onClick={handleAddPart4}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-50 text-rose-700 hover:bg-rose-100 rounded-xl text-xs font-bold transition"
            >
              <Plus className="w-4 h-4" />
              <span>Thêm bài tự luận</span>
            </button>
          </div>

          <div className="space-y-6">
            {data.part4.map((q, idx) => (
              <div key={q.id} className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-xs">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={q.code}
                      onChange={(e) => {
                        const copy = [...data.part4];
                        copy[idx].code = e.target.value;
                        setData({ ...data, part4: copy });
                      }}
                      className="w-20 px-2 py-1 font-bold text-xs border border-slate-300 rounded"
                    />
                    <select
                      value={q.level}
                      onChange={(e) => {
                        const copy = [...data.part4];
                        copy[idx].level = e.target.value as CognitiveLevel;
                        setData({ ...data, part4: copy });
                      }}
                      className="text-xs border border-slate-300 rounded px-2 py-1"
                    >
                      <option value="thong_hieu">Thông hiểu</option>
                      <option value="van_dung">Vận dụng</option>
                      <option value="van_dung_cao">Vận dụng cao</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 font-bold">Tổng điểm:</span>
                    <input
                      type="number"
                      step="0.25"
                      value={q.points}
                      onChange={(e) => {
                        const copy = [...data.part4];
                        copy[idx].points = Number(e.target.value);
                        setData({ ...data, part4: copy });
                      }}
                      className="w-16 px-2 py-1 text-xs border border-slate-300 rounded font-bold"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const copy = data.part4.filter((_, i) => i !== idx);
                        setData({ ...data, part4: copy });
                      }}
                      className="text-rose-500 hover:text-rose-700 p-1"
                      title="Xóa bài này"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Đề bài tự luận:</label>
                  <textarea
                    rows={3}
                    value={q.content}
                    onFocus={() => setFocusedInputInfo({ target: 'p4_content', index: idx })}
                    onChange={(e) => {
                      const copy = [...data.part4];
                      copy[idx].content = e.target.value;
                      setData({ ...data, part4: copy });
                    }}
                    className="w-full p-2.5 border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-rose-500 focus:outline-hidden"
                  />
                  <div className="mt-1 p-2 bg-slate-50 rounded border border-slate-200 text-xs">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                      Xem trước công thức:
                    </span>
                    <MathRenderer content={q.content} />
                  </div>
                </div>

                {/* Rubric steps */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-700">Các bước chấm điểm (Rubric):</label>
                    <button
                      type="button"
                      onClick={() => {
                        const copy = [...data.part4];
                        copy[idx].rubric.push({ stepDescription: 'Bước mới...', points: 0.5 });
                        setData({ ...data, part4: copy });
                      }}
                      className="text-xs text-indigo-600 font-bold hover:underline"
                    >
                      + Thêm bước
                    </button>
                  </div>
                  {q.rubric.map((r, rIdx) => (
                    <div key={rIdx} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={r.stepDescription}
                        onChange={(e) => {
                          const copy = [...data.part4];
                          copy[idx].rubric[rIdx].stepDescription = e.target.value;
                          setData({ ...data, part4: copy });
                        }}
                        className="flex-1 p-1.5 border border-slate-300 rounded text-xs text-slate-900"
                        placeholder="Mô tả tiêu chí/bước giải..."
                      />
                      <input
                        type="number"
                        step="0.25"
                        value={r.points}
                        onChange={(e) => {
                          const copy = [...data.part4];
                          copy[idx].rubric[rIdx].points = Number(e.target.value);
                          setData({ ...data, part4: copy });
                        }}
                        className="w-16 p-1.5 border border-slate-300 rounded text-xs font-bold"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const copy = [...data.part4];
                          copy[idx].rubric = copy[idx].rubric.filter((_, i) => i !== rIdx);
                          setData({ ...data, part4: copy });
                        }}
                        className="text-slate-400 hover:text-rose-500"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Solution */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Lời giải mẫu chi tiết:
                  </label>
                  <textarea
                    rows={4}
                    value={q.solution}
                    onFocus={() => setFocusedInputInfo({ target: 'p4_solution', index: idx })}
                    onChange={(e) => {
                      const copy = [...data.part4];
                      copy[idx].solution = e.target.value;
                      setData({ ...data, part4: copy });
                    }}
                    className="w-full p-2.5 border border-slate-300 rounded-lg text-sm text-slate-900 font-serif"
                  />
                  <div className="mt-1 p-2 bg-slate-50 rounded border border-slate-200 text-xs">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                      Xem trước lời giải:
                    </span>
                    <MathRenderer content={q.solution} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
